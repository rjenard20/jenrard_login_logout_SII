﻿
using System;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace nard_login
{
    public static class DatabaseHelper
    {
        // Locate the database in the main project folder
        private static readonly string DatabasePath =
            Path.GetFullPath(
                Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "..", "..", "..",
                    "RamirezLogin.accdb"));

        private static readonly string ConnectionString =
            $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={DatabasePath};Persist Security Info=False;";

        // Database connection
        private static OleDbConnection GetConnection()
        {
            if (!File.Exists(DatabasePath))
            {
                throw new FileNotFoundException(
                    "Database file not found!\n\nLocation:\n" +
                    DatabasePath);
            }

            return new OleDbConnection(ConnectionString);
        }

        // REGISTER USER
        public static bool RegisterUser(
            string fullName,
            string username,
            string password)
        {
            try
            {
                using (OleDbConnection connection = GetConnection())
                {
                    connection.Open();

                    // Check if username already exists
                    string checkQuery =
                        "SELECT COUNT(*) FROM [Users] WHERE [Username] = ?";

                    using (OleDbCommand check =
                        new OleDbCommand(checkQuery, connection))
                    {
                        check.Parameters.Add(
                            "?", OleDbType.VarWChar).Value = username;

                        int count =
                            Convert.ToInt32(check.ExecuteScalar());

                        if (count > 0)
                        {
                            MessageBox.Show(
                                "Username already exists!",
                                "Registration",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);

                            return false;
                        }
                    }

                    // Hash password using your existing PasswordHasher
                    string passwordHash =
                        PasswordHasher.HashPassword(password);

                    // Insert user into Access database
                    string insertQuery =
                        "INSERT INTO [Users] " +
                        "([FullName], [Username], [PasswordHash]) " +
                        "VALUES (?, ?, ?)";

                    using (OleDbCommand command =
                        new OleDbCommand(insertQuery, connection))
                    {
                        command.Parameters.Add(
                            "?", OleDbType.VarWChar).Value = fullName;

                        command.Parameters.Add(
                            "?", OleDbType.VarWChar).Value = username;

                        command.Parameters.Add(
                            "?", OleDbType.VarWChar).Value = passwordHash;

                        int result = command.ExecuteNonQuery();

                        return result > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Registration failed!\n\n" +
                    ex.Message +
                    "\n\nDatabase location:\n" +
                    DatabasePath,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return false;
            }
        }

        // LOGIN USER
        public static bool LoginUser(
            string username,
            string password,
            out string fullName)
        {
            fullName = "";

            try
            {
                using (OleDbConnection connection = GetConnection())
                {
                    connection.Open();

                    string query =
                        "SELECT [FullName], [PasswordHash] " +
                        "FROM [Users] WHERE [Username] = ?";

                    using (OleDbCommand command =
                        new OleDbCommand(query, connection))
                    {
                        command.Parameters.Add(
                            "?", OleDbType.VarWChar).Value = username;

                        using (OleDbDataReader reader =
                            command.ExecuteReader())
                        {
                            if (reader != null && reader.Read())
                            {
                                string storedName =
                                    reader["FullName"].ToString() ?? "";

                                string storedHash =
                                    reader["PasswordHash"].ToString() ?? "";

                                // Verify using your existing PasswordHasher
                                if (PasswordHasher.VerifyPassword(
                                    password, storedHash))
                                {
                                    fullName = storedName;
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Login failed!\n\n" + ex.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

            return false;
        }
    }
}
