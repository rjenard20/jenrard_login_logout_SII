﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace nard_login
{
    public partial class DashboardForm : Form
    {
        private readonly Action onLogout;

        public DashboardForm(string fullName, Action logout)
        {
            onLogout = logout;

            Text = "Dashboard";
            Size = new Size(800, 500);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(235, 235, 235);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Panel header = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(800, 90),
                BackColor = Color.FromArgb(55, 55, 55)
            };
            Controls.Add(header);

            Label title = new Label()
            {
                Text = "NARD LOGIN SYSTEM",
                Location = new Point(30, 25),
                AutoSize = true,
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                ForeColor = Color.White
            };
            header.Controls.Add(title);

            Label welcome = new Label()
            {
                Text = "Welcome, " + fullName + "!",
                Location = new Point(45, 140),
                AutoSize = true,
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.FromArgb(55, 55, 55)
            };
            Controls.Add(welcome);

            Label description = new Label()
            {
                Text = "You have successfully logged in.",
                Location = new Point(48, 195),
                AutoSize = true,
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.Gray
            };
            Controls.Add(description);

            Panel info = new Panel()
            {
                Location = new Point(45, 255),
                Size = new Size(690, 110),
                BackColor = Color.White
            };
            Controls.Add(info);

            Label account = new Label()
            {
                Text = "ACCOUNT INFORMATION",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.FromArgb(60, 60, 60)
            };
            info.Controls.Add(account);

            Label name = new Label()
            {
                Text = "Full Name: " + fullName,
                Location = new Point(20, 55),
                AutoSize = true,
                Font = new Font("Segoe UI", 11)
            };
            info.Controls.Add(name);

            Button btnLogout = new Button()
            {
                Text = "LOG OUT",
                Location = new Point(550, 395),
                Size = new Size(185, 42),
                BackColor = Color.FromArgb(65, 65, 65),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            btnLogout.Click += (s, e) => Close();
            Controls.Add(btnLogout);

            FormClosed += (s, e) => onLogout();
        }

        private void DashboardForm_Load(object? sender, EventArgs e)
        {
            // Dashboard load event
        }
    }
}
