﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace nard_login
{
    public partial class LoginForm : Form
    {
        TextBox txtUsername = new TextBox();
        TextBox txtPassword = new TextBox();

        public LoginForm()
        {
            Text = "Nard Login";
            Size = new Size(430, 500);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(230, 230, 230);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Label title = new Label()
            {
                Text = "USER LOGIN",
                Location = new Point(105, 45),
                AutoSize = true,
                Font = new Font("Segoe UI", 23, FontStyle.Bold),
                ForeColor = Color.FromArgb(55, 55, 55)
            };
            Controls.Add(title);

            Label subtitle = new Label()
            {
                Text = "Welcome! Please login to continue.",
                Location = new Point(75, 100),
                AutoSize = true,
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray
            };
            Controls.Add(subtitle);

            AddField("Username", txtUsername, 165);

            AddField("Password", txtPassword, 240);
            txtPassword.UseSystemPasswordChar = true;

            Button btnLogin = new Button()
            {
                Text = "LOGIN",
                Location = new Point(65, 320),
                Size = new Size(285, 42),
                BackColor = Color.FromArgb(65, 65, 65),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            NewMethod(btnLogin);
            Controls.Add(btnLogin);

            Button btnRegister = new Button()
            {
                Text = "CREATE ACCOUNT",
                Location = new Point(65, 375),
                Size = new Size(285, 38),
                BackColor = Color.FromArgb(190, 190, 190),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            btnRegister.Click += Register_Click;
            Controls.Add(btnRegister);

            Label footer = new Label()
            {
                Text = "NARD LOGIN SYSTEM",
                Location = new Point(130, 435),
                AutoSize = true,
                ForeColor = Color.Gray,
                Font = new Font("Segoe UI", 8)
            };
            Controls.Add(footer);

            AcceptButton = btnLogin;
        }

        private void NewMethod(Button btnLogin)
        {
            btnLogin.Click += Login_Click;
        }

        private void AddField(string label, TextBox textbox, int y)
        {
            Label lbl = new Label()
            {
                Text = label,
                Location = new Point(65, y),
                AutoSize = true,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            textbox.Location = new Point(65, y + 25);
            textbox.Size = new Size(285, 30);
            textbox.Font = new Font("Segoe UI", 11);

            Controls.Add(lbl);
            Controls.Add(textbox);
        }

        private void Login_Click(object? sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter your username and password.");
                return;
            }

            try
            {
                string fullName;

                bool success = DatabaseHelper.LoginUser(
                    username, password, out fullName);

                if (success)
                {
                    MessageBox.Show("Login successful! Welcome " + fullName);

                    this.Hide();

                    DashboardForm dashboard = new DashboardForm(
                        fullName,
                        () =>
                        {
                            this.Show();
                            txtPassword.Clear();
                            txtUsername.Clear();
                        });

                    dashboard.Show();
                }
                else
                {
                    MessageBox.Show("Invalid username or password.");
                    txtPassword.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Login error: " + ex.Message);
            }
        }

        private void Register_Click(object? sender, EventArgs e)
        {
            using (RegistrationForm registration = new RegistrationForm())
            {
                registration.ShowDialog(this);
            }
        }

        private void LoginForm_Load(object? sender, EventArgs e)
        {
            // Login load event
        }
    }
}
